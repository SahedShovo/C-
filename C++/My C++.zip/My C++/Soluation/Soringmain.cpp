#include <iostream>
#include <algorithm> 
using namespace std;

int main() {
    int arr[] = {5, 3, 8, 6, 2, 7, 4, 1}; // Example array
    int n = sizeof(arr) / sizeof(arr[0]); // Calculate the number of elements

    sort(arr, arr + n, greater<int>()); // Sort the array in descending order

    // Print the sorted array
    cout << "Sorted array in descending order: ";
    for(int i = 0; i < n; ++i) {
        cout << arr[i] << " ";
    }
    cout << endl;

    return 0;
}
