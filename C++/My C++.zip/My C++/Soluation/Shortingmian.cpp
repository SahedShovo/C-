#include <iostream>
#include<algorithm>
using namespace std;
int main(){
    int A[]={2,3,5,7,4,1,3,9};
    int n=sizeof(A)/sizeof(A[0]);
    sort(A,A+n,greater<int>());
    cout<<"Shorting Array:";
    for(int i=0;i<=n;i++){
        cout<<A[i]<<"";

    }
    cout<<endl;

}
