#include <iostream>
using namespace std;

int main() {
    int decimalNumber;

    // Get decimal number from user
    cout << "Enter a decimal number: ";
    cin >> decimalNumber;

    // Array to store binary number (assuming a maximum of 32 bits)
    int binaryArray[32];
    
    // Counter for binary array
    int index = 0;

    // If the input number is zero, handle this case separately
    if (decimalNumber == 0) {
        cout << "Binary equivalent: 0" << endl;
    } else {
        // Continue until the decimal number becomes 0
        while (decimalNumber > 0) {
            // Store the remainder when the number is divided by 2 (either 0 or 1)
            binaryArray[index] = decimalNumber % 2;
            // Divide the number by 2
            decimalNumber /= 2;
            // Move to the next position in the array
            index++;
        }

        // Print the binary number in reverse order
        cout << "Binary equivalent: ";
        for (int i = index - 1; i >= 0; i--) {
            cout << binaryArray[i];
        }
        cout << endl;
    }

    return 0;
}
