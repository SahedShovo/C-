#include <iostream>
using namespace std;
int main() {
    int numContestants = 10;
    int numQuestions = 1;

    int scores[10] = {0};

    // Simulate contest
    for (int question = 0; question < numQuestions; ++question) {
        // Simulate each question and update scores
        cout << "Question " << question + 1 << ":\n";
        for (int contestant = 0; contestant < numContestants; ++contestant) {
            // Simulate scoring for each contestant
            int score;
            cout << "Enter score for contestant " << contestant + 1 << ": ";
            cin >> score;
            scores[contestant] += score;
        }
    }

    // Find the winner
    int winner = 0;
    for (int i = 1; i < numContestants; ++i) {
        if (scores[i] > scores[winner]) {
            winner = i;
        }
    }

    // Display the winner
    cout << "The winner is contestant " << winner + 1 << " with a total score of " << scores[winner] << " points.\n";

    return 0;
}
