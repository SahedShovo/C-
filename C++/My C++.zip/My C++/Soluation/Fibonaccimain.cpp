#include <iostream>
using namespace std;
int main(){
    int c,n;
    int a =0;
    int b=1;
    cin>>n;
    for (int i=2;i<=n;i++){
        c=a+b;
        a=b;
        b=c;
    }
    cout<<"Nth Fibo:"<<b;
}
