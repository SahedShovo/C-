#include <iostream>
#include <cmath>
using namespace std;

int main() {
    // Define the binary number in an array
    const int size = 3; // Example size, you can adjust it as needed
    int binaryArray[size];

    // Input binary number from the user
    cout << "Enter an 8-bit binary number (one digit at a time): ";
    for (int i = 0; i < size; i++) {
        cin >> binaryArray[i];
    }

    int decimalNumber = 0;

    // Convert binary to decimal
    for (int i = 0; i < size; i++) {
        decimalNumber = decimalNumber * 2 + binaryArray[i];
    }

    // Output the decimal equivalent
    cout << "Decimal equivalent: " << decimalNumber << endl;

    return 0;
}
