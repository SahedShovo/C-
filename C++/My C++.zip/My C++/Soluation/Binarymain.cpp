#include <iostream>
using namespace std;
int main(){
    int A;
    cout<<"Enter:";
    cin>>A;
    int B[30];
    int index=0;
    if (A==0)
    {
        cout<<"Binary Equvalants =0";
    }
    else {
        while (A>0)
        {
            B[index]=A%2;
            A/=2;
            index++;
        }
        cout<<"Binary Number :";
        for (int i = index-1; i >=0; --i)
        {
            cout<<B[i];
        }
        cout<<endl;
        
        
    }
    

}
