#include <iostream>
using namespace std;

int main() {
    int size;
    
    cout << "Enter the size of the array: ";
    cin >> size;
    
    int nums[size];
    cout << "Enter the elements of the array (0s and 1s): ";
    for (int i = 0; i < size; i++) {
        cin >> nums[i];
    }
    
    int maxCount = 0;
    int currentCount = 0;
    
    for (int i = 0; i < size; i++) {
        if (nums[i] == 1) {
            currentCount++;
            if (currentCount > maxCount) {
                maxCount = currentCount;
            }
        } else {
            currentCount = 0;
        }
    }
    
    cout << "The maximum number of consecutive 1s is: " << maxCount << endl;
    
    return 0;
}
