#include<iostream>
using namespace std;
int prime[300000],nprime;
int mark[100002];
void sieve(int n){
    int i,j,limit=sqrt(n*1.0)+2;
    mark[1]=1;
    //for even number 
    for (int i = 4; i <= n; i+=2) mark[i]=1;
    
    prime[nprime++]=2;
    
    //Loop For Odds
    for(int i=3;i<=n;i+=2)
        if(!mark[i]){
            prime[nprime++]=i;
            if(i<=limit){
                for(int j=i*i;j<=n;j+=i*2){
                    mark[j]=1;
                }
            }
            }
} 
int main(){
    int n=100;
    sieve(n);
    for(int i=0;i<nprime;i++){
        cout<<prime[i]<<" "<<endl;
    }
    cout<<endl;
}
 