#include <iostream>
using namespace std;
int main() {
    int num, reversedNum = 0, remainder;

    cout << "Enter an integer: ";
    cin >> num;

    int tempNum = num;

    for (; tempNum != 0; tempNum /= 10) {
        remainder = tempNum % 10;
        reversedNum = reversedNum * 10 + remainder;
    }

    if (num == reversedNum) {
        cout << num << " is a palindrome." << endl;
    } else {
        cout << num << " is not a palindrome." << endl;
    }

    return 0;
}
