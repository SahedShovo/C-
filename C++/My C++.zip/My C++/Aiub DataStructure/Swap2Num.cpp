#include <iostream>
using namespace std;

void swap(int *a, int *b);

int main() {
    int num1 = 5, num2 = 10;
    cout << "Number1 = " << num1 << "\n";
    cout << "Number2 = " << num2 << "\n";
    swap(&num1, &num2);
    // Address of num1, num2 is passed
    cout << "Number1 = " << num1 << "\n";
    cout << "Number2 = " << num2 << "\n";
    return 0;
}

void swap(int *a, int *b) {
    // a, b points to &num1, &num2 respectively
    int t;
    t = *a;
    *a = *b;
    *b = t;
}
