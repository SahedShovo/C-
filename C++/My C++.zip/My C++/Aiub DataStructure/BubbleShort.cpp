#include <iostream>
using namespace std;
void bubbleSort(int A[], int N) {
    bool swapped = true;
    while (swapped) {
        swapped = false;
        for (int j = 0; j < N - 1; ++j) {
            if (A[j] > A[j + 1]) {
                swap(A[j], A[j + 1]);
                swapped = true;
            }
        }
    }
}

int main() {
    int A[] = {5, 3, 8, 4, 2};
    int N = sizeof(A) / sizeof(A[0]);

    cout << "Initial Array: ";
    for (int i = 0; i < N; ++i) {
        cout << A[i] << " ";
    }
    cout << endl;

    bubbleSort(A, N);

   cout << "Sorted Array: ";
    for (int i = 0; i < N; ++i) {
       cout << A[i] << " ";
    }
   cout << endl;

    return 0;
}
