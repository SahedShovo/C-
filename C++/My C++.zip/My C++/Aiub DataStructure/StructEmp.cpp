#include <iostream>
#include <cstring> // For strcpy
using namespace std;
struct EmployeeRecord {
    char name[5];
    int age;
    float salary;
};

int main() {
    EmployeeRecord x,y1, y[5], *p;

    // Setting values for x
    x.age = 22;
    x.salary = 1234.56;
    strcpy(x.name, "Sam");
     strcpy(y1.name, "Sa");
    // Setting values for an element of y
    y[2].age = 22;

    // Pointer manipulation
    p = &x;
    p->age = 22;

    // Print the values to verify
    cout << "x.name: " << x.name << endl;
    cout << "x.age: " << x.age <<endl;
    cout << "x.salary: " << x.salary << endl;

    cout << "y[2].age: " << y[2].age <<endl;

    cout << "p->name: " << p->name << endl;
    cout << "p->age: " << p->age << endl;
    cout << "p->salary: " << p->salary << endl;

    return 0;
}
