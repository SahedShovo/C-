#include <iostream>
using namespace std;

int main() {
    int array[5] = {1, 2, 3, 4, 5};
    cout << "Array: ";
    for (int i = 0; i < 5; ++i) {
         cout << array[i] << " ";
    }
    cout << endl;

    // Accessing elements
   cout << "First element: " << array[0] <<endl;

    // Modifying elements
    array[1] = 20;
    cout << "Modified array: ";
    for (int i = 0; i < 5; ++i) {
        cout << array[i] << " ";
    }
    cout << endl;

    return 0;
}
