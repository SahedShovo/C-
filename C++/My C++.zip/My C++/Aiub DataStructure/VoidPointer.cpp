#include <iostream>  // Include the necessary header for std::cout

// Function to increase the value pointed to by data
void increase(void *data, int psize) {
    if (psize == sizeof(char)) {  // Check if the size matches that of a char
        char *pchar = (char*)data;  // Cast the void* to char*
        ++(*pchar);  // Increment the value pointed to by pchar
    } else if (psize == sizeof(int)) {  // Check if the size matches that of an int
        int *pint = (int*)data;  // Cast the void* to int*
        ++(*pint);  // Increment the value pointed to by pint
    }
}

// Main function
int main(void) {
    char a = 'x';  // Initialize a character variable
    int b = 1602;  // Initialize an integer variable
    increase(&a, sizeof(a));  // Call increase function for the char variable
    increase(&b, sizeof(b));  // Call increase function for the int variable
    std::cout << a << ", " << b << std::endl;  // Print the results
    return 0;  // Return 0 to indicate successful execution
}
