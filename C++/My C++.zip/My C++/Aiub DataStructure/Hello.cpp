#include <iostream>

using namespace std;

void increase(void *data, int psize) {
    if (psize == sizeof(char)) {
        char *pchar = (char *)data;
        ++(*pchar);  // Increment the character
    } else if (psize == sizeof(int)) {
        int *pint = (int *)data;
        ++(*pint);  // Increment the integer
    }
}

int main() {
    char a = 'x'; // 'x' has ASCII value 120
    int b = 1602;

    increase(&a, sizeof(a));  // Increments 'x' to 'y' (ASCII value 121)
    increase(&b, sizeof(b));  // Increments 1602 to 1603

    cout << a << ", " << b << endl;  // Outputs: y, 1603
}
