#include<iostream>
#include<cstring>
using namespace std;
struct person{
    char name[30];
    person *child;
};
int main(){
    person p,*c;
    strcpy(p.name,"Sahed");
    c=p.child=new person[2];
    strcpy(c[0].name,"sara");
    c[0].child=NULL;
    strcpy(c[1].name,"Rahim");
    c=c[1].child=new person;
    strcpy(c->name,"Karim");
    c->child=NULL;
   cout << "P.Name: " << p.name << endl;
    cout << "P.Child[0].Name: " << p.child[0].name << endl;
    cout << "P.Child[1].Name: " << p.child[1].name << endl;
    cout << "P.Child[1].Child->Name: " << p.child[1].child->name << endl;

    // Deallocate the dynamically allocated memory
    delete[] p.child[1].child;
    delete[] p.child;

}