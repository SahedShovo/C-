#include<iostream>
using namespace std;
#define SQUARE(a)a*a;
int main(){
    cout<<SQUARE(4+3*4+3);
}