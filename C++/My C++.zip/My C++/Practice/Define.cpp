#include<iostream>
#define PI 3.1416
#define add(a,b) ((a)+(b))
using namespace std;
int main(){
    cout<<PI<<endl;
    int r=3;
    cout<<PI*r*r<<'\n';
    cout<<add(3,4);

}