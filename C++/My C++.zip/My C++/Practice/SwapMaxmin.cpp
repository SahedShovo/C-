#include<iostream>
using namespace std;

int main(){
	int N;cin>>N;
	int A[N+1];
	for(int i=1;i<=N;i++){
		cin>>A[i];
	}
	int minmum=1e9;
	for (int i = 1; i <=N; i++){
        minmum=min(minmum,A[i]);
    }
	int Maximum=-1e9;
	for(int i=1;i<=N;i++){
        Maximum=max(Maximum,A[i]);
		}
	
	swap(minmum,Maximum);
	for (int i = 0; i <=N; i++)
	{
		cout<<A[i]<<' ';
	}
	cout<<'\n';
	return 0;
}