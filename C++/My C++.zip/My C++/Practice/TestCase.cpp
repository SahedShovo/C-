#include<iostream>
using namespace  std;
const int inf=1e9;
int main(){
    int T,N;
    cin>>T;
    while(T--){
        int N;cin>>N;
        int A[N+1];
        for(int i=1;i<=N;i++){
            cin>>A[i];
    }
    int ans=inf;
    for(int i=1;i<=N;i++){
        for (int j = i+1; j <= N; j++)
        {
            ans=min(ans,A[i]+A[j]+j-i);
        }
        
    }
    cout<<ans<<'\n';
}
    
}
