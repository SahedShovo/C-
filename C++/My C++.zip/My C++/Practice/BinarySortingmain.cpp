#include<iostream>
using namespace std;
int main (){
    freopen("input.txt","a",stdin);
    freopen("output.txt","max",stdin);
    int a;
    cout<<"enter :";
    cin>>a;
    int b[a];
    cout<<"Enter 0 and 1 :";
    for(int i=0;i<a;i++){
        cin>>b[i];
    }
    int max=0;
    int currentCount=0;
    for(int i=0;i<a;i++){
        if (b[i]==1){
            currentCount++;
            if(currentCount>max){
                max=currentCount;
            }
            else{
                currentCount=0;
            }
           
        }

    }
     cout<<"The Max 1 is :"<<max;


}