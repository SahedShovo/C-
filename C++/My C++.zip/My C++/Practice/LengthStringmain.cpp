#include<iostream>
#include<string>
using namespace std;
int main(){
     string S ="Hello World";
     cout<<"Length is :"<<S.length()<<endl;
}