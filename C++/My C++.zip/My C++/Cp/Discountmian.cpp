#include<iostream>
using namespace std;
int main(){
    int A,B;
    cin>>A>>B;
    int Total=A-B;
    double dis=(double)Total/A*100;
    cout<<dis;
}
