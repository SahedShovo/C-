#include<iostream>
using namespace std;
int main(){
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
      int n;
      cin>>n;
      long long sum=(long long)n*(n+1)/2;
      long long sum_Powre_2=0;
      for(int i=1;i<=n;i*=2){
        sum_Powre_2+=i; 
      }
      long long ans=sum-2*sum_Powre_2;
      cout<<ans<<'\n';
    }
    return 0;

    }
