#include<iostream>
using namespace std;
bool Beautiful_Year(int n){
	int d4=n%10;
	n=n/10;
	int d3=n%10;
	n=n/10;
	int d2=n%10;
	n=n/10;
	int d1=n%10;
	n=n/10;
	if(d1!=d2&&d1!=d3&&d1!=d4&&d2!=d3&&d2&&d4&&d3!=d4){
		return true;
	}
	else{
		return false;
	}	
}
int main(){
	int y;
	cin>>y;
	y++;
	while(true){
		if (Beautiful_Year(y))
		{
		cout<<y<<'\n';
	}
	y++;
	}
	return 0;
	
}