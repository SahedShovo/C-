#include<iostream>
using namespace std;
int main (){
    int A,B;
    cin>>A>>B;
    int ans=A+(A-1);
    ans=max(ans,B+(B-1));
    ans=max(ans,A+B);
    cout<<ans<<endl;
}
      
       