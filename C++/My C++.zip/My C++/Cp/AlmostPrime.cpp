#include<iostream>
using namespace std;
int main(){
    int n,i,flag=0,result;
    cin>>n;
    for(int i=2;i<=n/2;i++){
        int reault=n%i;
        if (result==0){
           flag=1;
           break;
        }
    }
        if(flag==0){
            cout<<"Prime"<<n<<'\n';
        }
        else{
            cout<<"Not"<<i<<'\n';
        }
    }