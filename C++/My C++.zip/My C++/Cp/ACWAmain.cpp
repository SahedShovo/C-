#include<iostream>
using namespace std;
int main(){
    int n,m;
    cin>>n>>m;
    if (n==m){
        cout<<"Yes\n";
    }
    else{
        cout<<"No\n";
    }
}