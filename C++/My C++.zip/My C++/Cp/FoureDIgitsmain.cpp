#include<iostream>
using namespace std;
int main()
{
    int x;
    cin>>x;
    if (x<10){cout<<"000"<<x;}
    else if(x<100){cout<<"00"<<x;}
    else if(x<1000){cout<<"0"<<x;}
    else{cout<<x<<'\n';}

    return 0;

    }
