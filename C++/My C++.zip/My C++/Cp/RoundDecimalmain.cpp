#include<iostream>
#include<math.h>
using namespace std;
int main(){
    double a;
    cin>>a;
    cout<<round(a)<<'\n';
   
}
