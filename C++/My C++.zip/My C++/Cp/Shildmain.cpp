#include <iostream>
using namespace std;
int main(){
    int ivory,evory,total;
    cin>>ivory>>evory>>total;
    for(int i=0;i<=total;i+=evory){
        for(int j=0;j<=total;j+=ivory){
            if(i+j==total){
            cout<<"Yes\n";
            return 0;
            }
        }
    }
    cout<<"No\n";
    return 0;
}
