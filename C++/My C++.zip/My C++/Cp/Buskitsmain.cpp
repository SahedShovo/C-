#include<iostream>
using namespace std;
int main(){
	int a,b,c;
	cin>>a>>b>>c;
	for(int i=a;i<=b;i++){
        int ans =i%c;
		if (i%c==0)
		{
			cout<<ans;
		return 0;
        }
	}
    cout<<"-1";
    return 0;
}