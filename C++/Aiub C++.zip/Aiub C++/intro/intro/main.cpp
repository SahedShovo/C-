#include<iostream>
using namespace std;
int main() {
    int A[5][5],B[5][5],C[5][5],Row,Col,i,j;
    cout<<"Enter The Number of rows and Col:";
    cin>>Row>>Col;
    cout<<"Enter A Matrix:\n";
    for (i=0; i<Row; i++) {
        for (j=0; j<Col; j++) {
            cout<<"A["<<i<<"]"<<"["<<j<<"]"<<"=";
            cin>>A[i][j];
        }
    }
     // Printing A Matrix
    for (i=0; i<Row; i++) {
        for (j=0; j<Col; j++) {
            cout<<A[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<"Enter B Matrix:\n";
    for (i=0; i<Row; i++) {
        for (j=0; j<3; j++) {
            cout<<"B["<<Row<<"]"<<"["<<Col<<"]"<<"=";
            cin>>B[i][j];
        }
    }
    // Printing B Matrix
    for (i=0; i<Row; i++) {
        for (j=0; j<Col; j++) {
            cout<<B[i][j]<<" ";
        }
        cout<<endl;
    }
//    Adding Matrix
    cout<<"A+b"<<endl;
    for (i=0; i<Row; i++) {
        for(j=0;j<Col;j++){
            C[i][j]=A[i][j]+B[i][j];
        }
    }
    for (i=0; i<Row; i++) {
        for (j=0; j<Row; j++) {
            cout<<C[i][j]<<" ";
        }
        cout<<endl;

    }
                          
    
    
            return 0;
        }
        
