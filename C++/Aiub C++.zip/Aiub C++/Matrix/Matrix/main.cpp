#include<iostream>
using namespace std;
int main(){
    int n;
    cin>>n;
    for (int i=5464;i>n;i++){
        cout<<i;
       
     
        
            
        }
    return 0;
    }
