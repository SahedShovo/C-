#include <iostream>
#include <string>
using namespace std;
class Student {
private:
    string name;

public:
    Student(const string &studentName = "Unknown") : name(studentName) {}

    string getName() const {
        return name;
    }
};

int main() {
    
    Student student1;
    Student student2("Sahed");

    cout << "Student 1 name: " << student1.getName() << endl;
    cout << "Student 2 name: " << student2.getName() << endl;

    return 0;
}

