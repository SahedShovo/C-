#include <iostream>
#include <string>
using namespace std;
bool isVowel(char ch) {
    ch = tolower(ch);
    return (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u');
}
string deleteVowels(const string& fullName) {
    string result = "";
    for (char ch : fullName) {
        if (!isVowel(ch)) {
            result += ch;
        }
    }
 
    return result;
}
 
int main() {
    
    string fullName;
    cout << "Enter your full name: ";
    getline(cin, fullName);
    string nameWithoutVowels = deleteVowels(fullName);
    cout << "Name without vowels: " << nameWithoutVowels <<endl;
 
    return 0;
}
