#include <iostream>
#include <cmath>
using namespace std;
int main(){
    int A[5],sum=0;
    float Avg;
    cout<<"Enter Five Number:";
    for (int i=0; i<5; i++) {
        cin>>A[i];
        cout<<"Number["<<i+1<<"]="<<A[i]<<endl;
        sum+=A[i];
        float Avg= (double) A[i]/5;
    }
    cout<<"The Sum is:"<<sum<<endl;
    cout<<"The Avg is:"<<Avg;
    return 0;
}

